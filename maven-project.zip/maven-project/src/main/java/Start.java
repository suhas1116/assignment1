import java.util.Scanner;

/*
For detailed instructions, please refer to the README file.
It contains all the necessary guidelines and information for the project.
 */

public class Start {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //your code from here......
    }
}
